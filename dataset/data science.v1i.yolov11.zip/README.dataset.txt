# data science > 2024-12-01 10:51pm
https://universe.roboflow.com/fedi-qhzfy/data-science-eif4x

Provided by a Roboflow user
License: MIT

